# Change Log

All notable changes to the "xvba-ribbon" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

- Initial release

## [1.0.4]  - 30/04/2021 
### Add
- Add Link on Hover to see more details about the xml TAG 