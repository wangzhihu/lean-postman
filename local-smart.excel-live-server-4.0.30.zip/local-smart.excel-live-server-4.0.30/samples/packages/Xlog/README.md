# Xlog 
    
## Add Logs in excel vba
 - This package provides a way to add logs in Excel apss