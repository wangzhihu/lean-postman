from flask import Flask, render_template, request, redirect, session, url_for, make_response
from flask_login import UserMixin, LoginManager, login_required, login_user

app = Flask(__name__)
app.debug = True

app.secret_key = 'akj;cz891231nkl@a8sd@#@!'
app.config['SESSION_COOKIE_HTTPONLY'] = False

USERS = {
    1: {'name': '张三', 'age': 18, 'gender': '男', 'text': "道路千万条"},
    2: {'name': '李四', 'age': 28, 'gender': '男', 'text': "安全第一条"},
    3: {'name': '王五', 'age': 18, 'gender': '女', 'text': "行车不规范"},
}

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.session_protection = 'basic'
login_manager.login_view = 'login'
login_manager.login_message = u"请先登录。"


@login_manager.user_loader
def load_user(user_id):
    return USERS.get(user_id) if user_id in USERS else None


@app.route('/detail/<int:nid>', methods=['GET'])
def detail(nid):
    user = session.get('user_info')
    if not user:
        return redirect('/login')

    info = USERS.get(nid)
    return render_template('detail.html', info=info)


@app.route('/index', methods=['GET'])
@login_required
def index():
    # user = session.get('user_info')
    # if not user:
    #     url = url_for('l1')
    #     return redirect(url)

    return render_template('index.html', user_dict=USERS)


@app.route('/login', methods=['GET', 'POST'], endpoint='login')
def login():
    if request.method == 'GET':
        service = request.values['service'] if 'service' in request.values else '/login_success'
        return render_template('login.html', service=service)
    else:
        user = request.form.get('user')
        pwd = request.form.get('pwd')
        service_url = request.form.get('service')
        if user == 'zhangsan' and pwd == '12345':
            session['user_info'] = user
            return redirect(service_url)
        return render_template('login.html', error='用户名密码错误')


@app.route('/login_success', methods=['GET', 'POST'], endpoint='login_success')
def login_success():
    user = session.get('user_info')
    if not user:
        url = url_for('login')
        return redirect(url)
    response = make_response(render_template('login_success.html', user_name=user, user_dict=USERS))  # render_template()可以正常传递参数
    response.set_cookie('user_name', 'zhangsan', max_age=3600)
    response.set_cookie('it356', '123asda', max_age=3600, httponly=True)
    response.set_cookie('ebs env', 'test', max_age=3600)
    return response


# print('456')
# print(__name__)
if __name__ == '__main__':
    print('5555')
    app.run(host='0.0.0.0', port=80, debug=True)
# if __name__ == '__main__':
#     print('111111')
# app.run(host='0.0.0.0', port=80, debug=True)
