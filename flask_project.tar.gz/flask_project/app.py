from flask import Flask, request

app = Flask(__name__)


@app.route('/')
def index():
    print(request.path)
    return 'hello world'


@app.route('/hello')
def hello():
    print(request.path)
    return 'Hello Hello Hello'


if __name__ == '__main__':
    app.run()
