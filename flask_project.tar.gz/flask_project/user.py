from flask.ext.login import UserMixin
from flask_login import login_manager


class User(UserMixin):
    pass


users = {
    'zhangsan': {'username': 'zhangsan', 'password': '123'},
    'lisi': {'username': 'lisi', 'password': '456'}
}


def query_user(username):
    user = users[username] if username and username in users else None
    return user


@login_manager.user_loader
def load_user(username):
    user = query_user(username)
    if user:
        curr_user = User()
        curr_user.id = username
        return curr_user
